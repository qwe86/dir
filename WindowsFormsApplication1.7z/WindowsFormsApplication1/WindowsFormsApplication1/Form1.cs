﻿using MathNet.Numerics;
using MathNet.Numerics.Interpolation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZedGraph;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static public double Newton(double x, int n, List<double> MasX, List<double> MasY, double step)
        {
            double[,] mas = new double[n + 2, n + 1];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < n + 1; j++)
                {
                    if (i == 0)
                        mas[i, j] = MasX[j];
                    else if (i == 1)
                        mas[i, j] = MasY[j];
                }
            }
            int m = n;
            for (int i = 2; i < n + 2; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    mas[i, j] = mas[i - 1, j + 1] - mas[i - 1, j];
                }
                m--;
            }

            double[] dy0 = new double[n + 1];

            for (int i = 0; i < n + 1; i++)
            {
                dy0[i] = mas[i + 1, 0];
            }

            double res = dy0[0];
            double[] xn = new double[n];
            xn[0] = x - mas[0, 0];

            for (int i = 1; i < n; i++)
            {
                double ans = xn[i - 1] * (x - mas[0, i]);
                xn[i] = ans;
                ans = 0;
            }

            int m1 = n + 1;
            int fact = 1;
            for (int i = 1; i < m1; i++)
            {
                fact = fact * i;
                res = res + (dy0[i] * xn[i - 1]) / (fact * Math.Pow(step, i));
            }

            return res;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x = 7.5;
            double step = 0.1;
            int n = 3;
            List<double> MasX = new List <double> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
            List<double> MasY =  new List<double> { 1020000, 1337700, 1253450, 1026900, 1269750, 982600, 1208150, 1122600, 1258350, 972600, 991400, 1214950, 1011650, 1123550, 1202800, 1201500, 1119600, 1122850, 1214650 };
            List<double> masY_temp;
            List<double> masX_temp;
            GraphPane pane = zedGraphControl1.GraphPane;

            pane.CurveList.Clear();

            PointPairList list = new PointPairList();

            //double xmin = 1;
            //double xmax = 3;
            masX_temp = new List<double>();
            masY_temp = new List<double>();
            for (int X = 1; X <= 17; X += 2)
            {
                masX_temp.Clear();
                masX_temp.Add(X);
                masX_temp.Add(X+1);
                masX_temp.Add(X+2);
                
                masY_temp.Clear();
                masY_temp.Add(MasY[X-1]);
                masY_temp.Add(MasY[X]);
                masY_temp.Add(MasY[X+1]);
                
                // Заполняем список точек
                for (double X_temp = masX_temp[0]; X_temp <= masX_temp[2]; X_temp += 0.0416)
                {
                    // добавим в список точку
                    list.Add(X_temp, Newton(X_temp, 2, masX_temp, masY_temp, 1));
                }
                

            }

            // Создадим кривую с названием "Sinc", 
            // которая будет рисоваться голубым цветом (Color.Blue),
            // Опорные точки выделяться не будут (SymbolType.None)
            LineItem myCurve = pane.AddCurve("exam", list, Color.Blue, SymbolType.Diamond);
            zedGraphControl1.AxisChange();
            zedGraphControl1.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double[] MasX = new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
            double[] MasY = new double[] { 1020000, 1337700, 1253450, 1026900, 1269750, 982600, 1208150, 1122600, 1258350, 972600, 991400, 1214950, 1011650, 1123550, 1202800, 1201500, 1119600, 1122850, 1214650};

            double[] masY_temp;
            double[] masX_temp;

            double NewYValue;
            PointPairList list = new PointPairList();

            for (int i =1; i <= 17; i+=2)
            {
                masY_temp = new double[3];
                masX_temp = new double[3];
                masX_temp[0] = i;
                masX_temp[1] = i+1;
                masX_temp[2] = i+2;
                masY_temp[0] = MasY[i-1];
                masY_temp[1] = MasY[i];
                masY_temp[2] = MasY[i+1];
                NevillePolynomialInterpolation objIterpolate = new NevillePolynomialInterpolation(masX_temp, masY_temp);
                for (double j = masX_temp[0]; j <= masX_temp[2]; j+=0.0416)
                {
                    NewYValue = Math.Abs(objIterpolate.Interpolate(j));
                    list.Add(j, NewYValue);
                }
            }
                       
            GraphPane pane = zedGraphControl2.GraphPane;

            pane.CurveList.Clear();

           
            LineItem myCurve = pane.AddCurve("exam", list, Color.Blue, SymbolType.Diamond);
            zedGraphControl2.AxisChange();
            zedGraphControl2.Invalidate();
            
        }
        
    }
}
