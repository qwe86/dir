var table;
window.onload = function() {
	table = new Vue ({
		el: '#table1',
		data: {
			rows: [
			]
		},
		computed: {
			"columns": function columns() {
				if (this.rows.length == 0) {
					return [];
				}
				return Object.keys(this.rows[0])
			}
		}
	});
	new Vue ({
		el: '#btn1',
		methods: {
			addItem: function() {
				alert("!!");
				var obj = {
					sid: document.getElementById("sid_conf").value,
					typ: document.getElementById("type_conf").value,
					user: document.getElementById("user_conf").value,
					password: document.getElementById("password_conf").value,
					key_conf: document.getElementById("key_conf").value,
					storage: document.getElementById("storage_conf").value	
				};
				table.rows.push(obj);
			}
		}
	});
}