﻿export var calendar;
document.addEventListener('DOMContentLoaded',
function() {
	var calendarEl = document.getElementById('calendar');
	calendar = new FullCalendar.Calendar(calendarEl, {
		plugins: ['interaction','dayGrid', 'timeGrid', 'list', 'bootstrap'],
		locale:'ru',
		height:500,
		themeSystem:'bootstrap',
		customButtons: {
			myButton: {
				text:"Добавить",
				click: function() {
				alert("!");
				calendar.addEvent({
					
					title: document.getElementById('process_text'),
					start: document.getElementById('begin_process'),
					end: document.getElementById('end_process')
				});
				calendar.render();
				}
			}
		},
		header: {
			left: 'prev, next today',
			center: 'title',
			right: 'dayGridMonth, timeGridWeek, timeGridDay, listMonth, myButton'
		},
		weekNumbers:true,
		selectable: true,
		editable: true,
		/*select: function(arg) {
        
		calendar.addEvent({
			title: document.getElementById('process_text'),
			start: document.getElementById('begin_process'),
			end: document.getElementById('end_process')
		})
        calendar.unselect()
        }*/
        
		
	});
	calendar.render();
});
