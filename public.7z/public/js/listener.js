var socket;
var str = "";
var data = [];
import {calendar} from "./FullCalendar.js";
window.onload = function() {
	/*month = new Vue({
		el: '#month',
		data: {
			cols: [
				{"name": 'jan',
				 "text": "Январь"},
				{"name":'feb',
				 "text": "Февраль"},
				 {"name":'mar',
				 "text": "Март"},
				 {"name":'apr',
				 "text": "Апрель"},
				 {"name":'may',
				 "text": "Май"},
				 {"name":'jun',
				 "text": "Июнь"},
				 {"name":'jul',
				 "text": "Июль"},
				 {"name":'aug',
				 "text": "Август"},
				 {"name":'sep',
				 "text": "Сентябрь"},
				 {"name":'okt',
				 "text": "Октябрь"},
				 {"name":'nov',
				 "text": "Ноябрь"},
				 {"name":'dec',
				 "text": "Декабрь"}
			]
		}
	});*/
	
	var table = new Vue ({
		el: '#table1',
		data: {
			rows: [
			]
		},
		methods: {
			addRowHandlers: function() {
			  var t = document.getElementById("table1");
			  var r = t.getElementsByTagName("tr");
			  for (i = 1; i < r.length; i++) {
					var currentRow = r[i];
					var createClickHandler = function(row) {
					  return function() {
						var t = document.getElementById("table1");
						var rows = t.getElementsByTagName("tr");
						for (i = 1; i < rows.length; i++) {
							r[i].style.background = null;
						}
						var cell = row.getElementsByTagName("td")[0];
						row.style.background = 'yellow';
						var id = cell.innerHTML;
					  };
					};
					currentRow.onclick = createClickHandler(currentRow);
				}	
			}
		},
		computed: {
			"columns": function columns() {
				if (this.rows.length == 0) {
					return [];
				}
				return Object.keys(this.rows[0])
			}
		}
	});
	var adding = new Vue ({
		el: '#add_button',
		methods: {
			addItem: function() {
					var t = document.getElementById("table1");
					var rows = t.getElementsByTagName("tr");
					for (i = 1; i < rows.length; i++) {
						rows[i].style.background = null;
					}
					document.getElementById("sid_conf").value = "";
					document.getElementById("type_conf").value = ""
					document.getElementById("user_conf").value = "";
					$(document).ready(function() {
						$('#conf_modal').modal('show')
					});
				}
			}
		
	});
	new Vue ({
		el: '#import_button',
		methods: {
			import_ok: function(data) {
				alert('vue');
				socket.emit('import_vbs', document.getElementById("systemOption").value + document.getElementById("txt").value);
			}
		}
	});
	var save_modal = new Vue ({
		el: '#save_modal',
		methods: {
			edit: function() {
				var f = true;
				
				var obj = {
					"SID": document.getElementById("sid_conf").value,
					"Тип": document.getElementById("type_conf").value,
					"Пользователь": document.getElementById("user_conf").value
				};
				var t = document.getElementById("table1");
				var rows = t.getElementsByTagName("tr");
				for (i = 1; i < rows.length; i++) {
					if (rows[i].style.background == "yellow") {
						rows[i].cells[0].innerText = document.getElementById("sid_conf").value;
						rows[i].cells[1].innerText = document.getElementById("type_conf").value;
						rows[i].cells[2].innerText = document.getElementById("user_conf").value;
						f = false;
					}
				}
				if (f) {
					table.rows.push(obj);
					data.push(obj);
				}				
					
				
				
			}
		}
	});
	
	var editing = new Vue ({
		el: '#edit_button',
		methods: {
			edit: function() {
			
				var t = document.getElementById("table1");
				var rows = t.getElementsByTagName("tr");
				for (i = 1; i < rows.length; i++) {
					if (rows[i].style.background == "yellow") {
						
						document.getElementById("sid_conf").value = rows[i].cells[0].innerText;
						document.getElementById("type_conf").value = rows[i].cells[1].innerText;
						document.getElementById("user_conf").value = rows[i].cells[2].innerText;
						$(document).ready(function() {
							$('#conf_modal').modal('show')
						});
					}
				}
			}
		}
		
	});
	var removing = new Vue ({
		el: '#remove_button',
		methods: {
			remove: function() {
			
				var t = document.getElementById("table1");
				var rows = t.getElementsByTagName("tr");
				for (i = 1; i < rows.length; i++) {
					if (rows[i].style.background == "yellow") {
						rows[i].parentNode.removeChild(rows[i]);
					}
				}
			}
		}
		
	});
	
	var active = new Vue ({
		el: '#db_active',
		methods: {
			active: function() {
				alert("!");
				var socket = io();
				socket.emit("db_activate","active");
			}
		}
		
	});
	var act= new Vue ({
		el: '#process_save',
		methods: {
			process_save: function() {
				$(document).ready(function() {
					alert($('calendar').fullCalendar('clientevents'));
				});
			}
		}
				
	});
	
	
	
}