var table;
var socket;
var str = ""
var data = []
window.onload = function() {
	
	month = new Vue({
		el: '#month',
		data: {
			cols: [
				{"name": 'jan',
				 "text": "Январь"},
				{"name":'feb',
				 "text": "Февраль"},
				 {"name":'mar',
				 "text": "Март"},
				 {"name":'apr',
				 "text": "Апрель"},
				 {"name":'may',
				 "text": "Май"},
				 {"name":'jun',
				 "text": "Июнь"},
				 {"name":'jul',
				 "text": "Июль"},
				 {"name":'aug',
				 "text": "Август"},
				 {"name":'sep',
				 "text": "Сентябрь"},
				 {"name":'okt',
				 "text": "Октябрь"},
				 {"name":'nov',
				 "text": "Ноябрь"},
				 {"name":'dec',
				 "text": "Декабрь"}
			]
		}
	});
	table = new Vue ({
		el: '#table1',
		data: {
			rows: [
			]
		},
		methods: {
			addRowHandlers: function() {
			  var t = document.getElementById("table1");
			  var rows = t.getElementsByTagName("tr");
			  for (i = 0; i < rows.length; i++) {
					var currentRow = t.rows[i];
					var createClickHandler = function(row) {
					  return function() {
						var t = document.getElementById("table1");
						var rows = t.getElementsByTagName("tr");
						for (i = 0; i < rows.length; i++) {
							t.rows[i].style.background = "white";
						}
						var cell = row.getElementsByTagName("td")[0];
						row.style.background = 'yellow';
						var id = cell.innerHTML;
					  };
					};
					currentRow.onclick = createClickHandler(currentRow);
				}	
			}
		},
		computed: {
			"columns": function columns() {
				if (this.rows.length == 0) {
					return [];
				}
				return Object.keys(this.rows[0])
			}
		}
	});
	var edding = new Vue ({
		el: '#btn1',
		methods: {
			addItem: function(str) {
				
				var obj = {
					"SID": document.getElementById("sid_conf").value,
					"Тип": document.getElementById("type_conf").value,
					"Пользователь": document.getElementById("user_conf").value
				};
				if (str = "edit") {
					str = "";
					
					var rows = table.getElementsByTagName("tr");
					for (i = 0; i < data.length; i++) {
					
						if (rows[i].style.background = 'yellow') {
							rows[i]['SID'] = document.getElementById("sid_conf").value;
							rows[i]['Тип'] = document.getElementById("type_conf").value;
							rows[i]['Пользователь'] = document.getElementById("user_conf").value;
							data[i]['SID'] = document.getElementById("sid_conf").value;
							data[i]['Тип'] = document.getElementById("type_conf").value;
							data[i]['Пользователь'] = document.getElementById("user_conf").value;
						}
						
					}
				}
				else {
				
				table.rows.push(obj);
				data.push(obj);
				alert(table.rows[0]['SID']);
				}
			}
		}
	});
	new Vue ({
		el: '#import_button',
		methods: {
			import_ok: function(data) {
				alert('vue');
				socket.emit('import_vbs', document.getElementById("systemOption").value + document.getElementById("txt").value);
			}
		}
	});
	var edit = new Vue ({
		el: '#change_button',
		methods: {
			edit: function() {
				
				var tabl = document.getElementById("table1");
				var rows = tabl.getElementsByTagName("tr");
				for (i = 0; i < data.length; i++) {
						if (rows[i].style.background = 'yellow') {
							str = "edit";
							document.getElementById("sid_conf").value = data[i]['SID'];
							document.getElementById("type_conf").value = data[i]['Тип'];
							document.getElementById("user_conf").value = data[i]['Пользователь'];
							$(document).ready(function() {
								$('#conf_modal').modal('show')
							});
						}
				}
			}
		}
	});
	
}