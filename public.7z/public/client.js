var 
var socket = io.connect();
socket.on('clicked', function (data) {
    console.log(data);
    socket.emit('my other event', { my: 'data' });
});
function osClick(_btn) {
    socket.emit('clicked', "1");
}