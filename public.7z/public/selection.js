﻿function selection() {
    var R3R =
        [
            {
                "text": "di1R3R",
                "value":"di1R3R"
            },
            {
                "text": "di2R3R",
                "value": "di2R3R"
            }
            {
                "text": "di3R3R",
                "value": "di3R3R"
            }
            {
                "text": "di4R3R",
                "value": "di4R3R"
            }
            
        ];
    var PBW =
        [
            {
                "text": "di1PBW",
                "value": "di1PBW"
            },
            {
                "text": "di2PBW",
                "value": "di2PBW"
            }

        ];
    var system =  document.getElementById('systemOption').value;
    var selectBox = document.getElementById('instanceOption');

    selectBox.selected = null;
    var length = selectBox.options.length;
    for (i = 0; i < length; i++) {
        selectBox.options[i] = null;
    }

    if (system == 'R3R') {
        length = selectBox.options.length;
        for (i = 0; i < length; i++) {
            selectBox.options[i] = null;
        }

        for (var i = 0, l = R3R.length; i < l; i++) {
            var option = R3R[i];
            selectBox.add(new Option(option.text, option.value, option.selected));
        }
    }
    if (system == 'PBW') {
        length = selectBox.options.length;
        for (i = 0; i < length; i++) {
            selectBox.options[i] = null;
        }

        for (var i = 0, l = PBW.length; i < l; i++) {
            var option = PBW[i];
            selectBox.add(new Option(option.text, option.value, option.selected));
        }
    }
}