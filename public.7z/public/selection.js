﻿function selection() {
	
	var system =  document.getElementById('import_system_db').value;
	switch (system) {
		case "R3R":
			 document.getElementById('import_db_R3R').style.display="block";
			 document.getElementById('import_db_ECP').style.display="none";
		break;
		case "ECP":
			document.getElementById('import_db_ECP').style.display="block";
			document.getElementById('import_db_R3R').style.display="none";
		break;
	}
}