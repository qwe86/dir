
var io = require('/socket.io/socket.io.js');
var socket = io();
function osClick(_btn) {
	alert("click");
	socket.emit('clicked', "1");
}
socket.on('clicked', function (data) {
	document.getElementById("txt").value = "Johnny Bravo";

});