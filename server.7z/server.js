﻿var hanaClient = require("@sap/hana-client");
const path = require('path');
var mysql = require('mysql');
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var bodyParser = require('body-parser');
var rexec = require('remote-exec');
var child = require('child_process');
var db_check = false;
var res = "!"
var fs = require('fs');
var XLSX = require('xlsx');
var i;
var data;
// var connection = mysql.createConnection({
    // host: 'localhost',
    // user: 'root',
    // password: 'Alexvent555666!',
// });
var connection = hanaClient.createConnection();
var connection1 = hanaClient.createConnection();
// see documentation for the ssh2 npm package for a list of all options 

var hana_option_haq = {
	host: 'hanahaq',
	port: 36215,
	username: 'SYSTEM',
	password: 'SYS_hanaHAP1',
	databaseName: 'HAQ'
};
var hana_option_had = {
	host: 'hanahad',
	port: 36115,
	username: 'SYSTEM',
	password: 'HADh4n4SYS1',
	databaseName: 'HAD'
};

const connection_options = {
	port: 22,
	username: 'pbwadm',
	privateKey: require('fs').readFileSync('C:/Users/Bazhaev_AB/Desktop/keys/id_rsa'),
	passphrase: 'Lo4815162342!',
	stdout: fs.createWriteStream('./output.txt')
};
var hosts = [
	'sdx12-01'
];

var cmds = [
	'top -b -n 1 | grep bw0adm | grep hdbind+'
];

var urlencodedParser = bodyParser.urlencoded({ extended: false })
function cpu() {
	rexec(hosts, cmds, connection_options, function(err){
		if (err) {
			console.log(err);
		} else {
			fs.readFile("./output.txt", 'UTF8', function (err, buf) {
				io.emit("response",buf);
			});
		}
		});
	
}

function hana_locks1() {
	connection1.connect(hana_option_had, (err) => {
		if (err) {
			io.emit("err_db", JSON.stringify(err));
			//return console.error("Connection error", err);
		}

		const whereClause = process.argv[2] ? `WHERE "group" = '${process.argv[2]}'` : "";
		const sql = 'select count(*) from SYS.M_TABLE_LOCKS';
		
		connection1.exec(sql, (err, rows) => {
			connection1.disconnect();

			if (err) {
				return console.error('SQL execute error:', err);
			}
			//console.log(rows);
			io.emit("response_db", JSON.stringify(rows));
			//console.log(`Query '${sql}' returned ${rows.length} items`);
		});
		});
}



app.use(bodyParser.urlencoded({ extended: false }))

app.use("/", require('express').static(__dirname + '/public'));

app.get('/', urlencodedParser, function (req, res) {
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});
function go() {
	console.log("End!!");
}
io.on('connection', function (client) {
    
    client.on('import_vbs', function (data) {
		/*console.log("import_vbs_running");
		system = data.substr(0,3);
		const util = require("util");
		const { exec } = require("child_process");
		const execProm = util.promisify(exec);
		
		async function run_shell_command(command) {
		   let result = "!!";
		   try {
			 result = await execProm(command);
		   } catch(ex) {
			  result = ex;
		   }
		   if ( Error[Symbol.hasInstance](result) )
			   return ;
			res = result;
		   return result;
		}
		run_shell_command("cscript D:\x2Flogin.vbs").then(result =>	adding(JSON.stringify(result)));*/
		var workbook = XLSX.readFile("D:\x2F1.xlsx");
	
		const wsname = workbook.SheetNames[0];
		const ws = workbook.Sheets[wsname];
		var time = ""
		for (i = 2; i <= 18; i++) {
			time+=" " + ws["A" + i.toString()].v+" "+ ws["D" + i.toString()].v;
		}
		io.emit("import_resp", time);
		
		
	});
	client.on("db_activate", function (data) {
		setInterval(cpu, 2000);
		setInterval(hana_locks1, 2000);
	});
	
    
});

//connection.connect();
//занесение данных в бд
function adding(resp) {
	var workbook = XLSX.readFile("D:\x2F1.xlsx");
	
		const wsname = workbook.SheetNames[0];
		const ws = workbook.Sheets[wsname];
		for (i = 2; i <= 18; i++) {
			console.log(ws["A" + i.toString()].v);
		}
}
function intervalFunc() {
    var retValue;

    var query = connection.query('SELECT count(*) FROM db.example;');
    query
        .on('error', function (err) {
            
        })
        .on('fields', function (fields) {
            
        })
        .on('result', function (row) {
            
            connection.pause();
            processRow(row);
            console.log(retValue); 
        })
        .on('end', function (row) {

        });
    
    function processRow(rows) {
        retValue = rows;
    }

    console.log(retValue); 
}



http.listen(3000, function () {
    console.log('listening on *:3000');
});